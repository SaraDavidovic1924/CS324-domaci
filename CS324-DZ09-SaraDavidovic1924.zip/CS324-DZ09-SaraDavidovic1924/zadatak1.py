#!/usr/bin/python
import Person as Persons
import mysql.connector
from Person import *

name = raw_input("Name: ")
lastName = raw_input("Last name: ")
age = raw_input("Age: ")

persons = Persons(name, lastName, age)
persons.persistPerson()

persons.fetchPersons()


