#!/usr/bin/python
import pymysql
import mysql.connector

class Persons:
    def __init__(self, name, lastName, age):
        self.name = name
        self.lastName = lastName
        self.age = age

    def persistPerson(self):
        try:
            connection = mysql.connector.connect(user='root', password='', host='127.0.0.1', database='cs324-dz09')
            cursor = connection.cursor()
            cursor.execute("INSERT INTO PERSONS(name, lastName, age) VALUES (%s, %s, %s)", (self.name, self.lastName, self.age))
            connection.commit()
            print ("Saved")

        except:
            connection.rollback()
            print ("Not saved")

        cursor.close()

    def fetchPersons(self):
         connection = mysql.connector.connect(user='root', password='', host='127.0.0.1', database='cs324-dz09')
         cursor = connection.cursor()
         cursor.execute("SELECT * FROM PERSONS")

         data = cursor.fetchall()
         print ("Database: \n")
         print(data)


