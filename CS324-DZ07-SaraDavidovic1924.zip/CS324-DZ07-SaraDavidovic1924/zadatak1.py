#! /usr/bin/python
def fun(a,b):

    if(a<b):
        return a+b
    elif(a>=b):
        return a*b

print(fun(2,3))
