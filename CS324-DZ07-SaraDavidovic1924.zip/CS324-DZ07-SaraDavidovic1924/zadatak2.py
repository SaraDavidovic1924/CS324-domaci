#zadatak 2
def fun(niz):

    newList = []

    i = 0
    while i < len(niz):

        newList.append(niz[i]+1)
        i+=1

    return newList
lista=[1,2,3,4,5]
print(fun(lista))
