#! usr/bin/phyton
arr1 = [1 ,3 ,5]
arr2 = [2 ,4 ,6]

def rekurzija(arr1, arr2, i = 0):
    if i < min(len(arr1), len(arr2)):
        return [arr1[i] + arr2[i]] + rekurzija(arr1, arr2, i + 1)
    else:
        return []

print (rekurzija(arr1, arr2))
