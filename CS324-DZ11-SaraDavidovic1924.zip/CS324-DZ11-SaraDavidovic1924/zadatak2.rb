class WordCount

  def initialize(sentence)
    @sentence = sentence
    @counts = Hash.new(0)
  end

  def count_word
    names = @sentence.split(/\W+/)
    names.each { |word| @counts[word] += 1 }
  end

  def print_count
    @counts.each_pair {|key, value| puts "#{key.inspect} : #{value}"}
  end
end

test = WordCount.new("Rec 'puta' se ponavlja dva puta u ovoj recenici")
test.count_word()
test.print_count()