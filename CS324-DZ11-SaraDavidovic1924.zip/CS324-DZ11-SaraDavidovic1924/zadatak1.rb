def izdvoj_kvadrate(array)
  result = array.select { |x| provera(Math.sqrt(x))}
  return result
end


def provera(num)
  num % 1 == 0
end

testArray = [1, 2,3,4,5,6,7,8,9,10,22,33,44,100,1000]
array = izdvoj_kvadrate(testArray)
p array