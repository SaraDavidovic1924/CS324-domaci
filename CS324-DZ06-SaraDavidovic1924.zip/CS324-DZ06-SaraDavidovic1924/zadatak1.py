#!/usr/bin/python
#zadatak 1
print("Prvi zadatak: ")
def funkcija(a, b , c = "+"):
	if c == "+":
		return a + b
	elif c == "*":
		return a * b

print(funkcija(10,10, "*"))
