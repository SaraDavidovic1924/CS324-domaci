#!/usr/bin/python

#zadatak 2

print ("Drugi zadatak: ")

niz = [1,2,3,4,5,6,7,8,9]


def first():
	return niz[0];

print (first())

def last():
	return niz[-1];
print (last())

def tail():
	return niz[1:]
print (tail())

def init():
	return niz[:len(niz) - 1]
print (init())

