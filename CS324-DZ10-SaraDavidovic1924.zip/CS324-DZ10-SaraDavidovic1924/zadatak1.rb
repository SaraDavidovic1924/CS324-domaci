module NZD
  refine Integer do
    def nzd(a=self, b)
      if a % b == 0
        b
      else
        nzd(b, a % b)
      end
    end
  end
end

using NZD

print " Najveci zajednicki delilac  za brojeve 12 i 4 je : \n"
puts 12.nzd(4)
print " Najveci zajednicki delilac  za brojeve 110 i 20 je : \n"

puts 110.nzd(20)