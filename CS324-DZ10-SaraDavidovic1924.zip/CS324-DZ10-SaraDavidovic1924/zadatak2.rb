def some_method(message)

  if message.empty? || message.nil? || message == " "
    "Prazno"

  elsif message.length <= 5
    "Kratko"

  elsif message.length >= 6 && message.length <= 11
    "Srednje dugo"

  elsif message.length >= 12
    "Dugo"

  else
    "Rec nit je prazna, nit je kratka, nit je srednje duga, nit je duga."
  end

end

puts "Unesite rec:"
user_input = STDIN.gets.chop
puts some_method(user_input)