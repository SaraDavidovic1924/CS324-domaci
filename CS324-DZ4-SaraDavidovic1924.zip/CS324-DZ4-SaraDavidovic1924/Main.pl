#!/usr/bin/perl

use BankAccount;
print "Vas bankarski racun!\n";
$object = new BankAccount("Vase ime je: Sara","Vase prezime je: Davidovic", 1000);
print"================================================================================";
print "\n";

	
	
	
	print "Banka Vam je uplatila depozit u iznosu od:150.000,00 din \n";
	$amount = 150000;
	$object->deposit($amount);
	print "Stanje:". $object->getBalance . "\n";
	
	print "Podigli ste novac u iznosu od: 150.000,00 din \n";
	$withdraw = 150000;
	$object->withdraw($withdraw);

	print "Stanje:". $object->getBalance . "\n";
	
