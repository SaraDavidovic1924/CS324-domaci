#!/usr/bin/perl
#2) Kreirati niz @numbers koji sadrži brojeve od 1 do 10. Koristiti while petlju i shift funkciju, i
#ispisati kvadrat svakog broja u nizu.

#niz numbers koji sadrzi brojeve od 1 do 10
@numbers = (1 .. 10);

#koristim while petlju koji ispisuje brojeve 

while(@numbers){
	my $i = shift(@numbers);
	printf $i**2 . "\n";

}



