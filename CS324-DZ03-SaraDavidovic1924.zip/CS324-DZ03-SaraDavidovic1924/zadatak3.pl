#!/usr/bin/perl
#3) Napisati skriptu (reverse_word.pl) koja od korisnika sa STDIN uzima rečenicu i ispisuje je
#tako da su sve reči napisane obrnuto.
#Korisnik unosi neki tekst ili broj sa tastature
$userInput = <STDIN>;
#reverseWords prikazuje uneseni text napisan u 'rikverc' koristeci funkciju reverse
@reverseWords = reverse split(" ", reverse($userInput));

printf "@reverseWords \n";
