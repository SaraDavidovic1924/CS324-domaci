#!/usr/bin/perl
#Uz pomoć foreach petlje, proći kroz brojeve od 1 do 10 i ispisati njihove kvadrate. Koristiti
#range operator za kreiranje liste brojeva.
#FOREACH petlja koja nam prikazuje brojeve od 1 do 10.
foreach $i (1 .. 10){
	#printf ispisuje kvadrat broja koji smo dobili u petlji.
	printf $i**2 ."\n";}

