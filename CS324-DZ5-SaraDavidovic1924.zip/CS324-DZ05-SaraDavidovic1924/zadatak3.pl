#!/usr/bin/perl
#3) Napisati Perl program koji uzima listu brojeva i ispisuje one koji su iznad proseka u listi
#(napisati poseban sub koji računa prosek).

use strict;
use warnings;
use v5.010;


my @listaBrojeva = (1..11);

sub avg {
	my $ukupno = 0;
	$ukupno += $_ foreach @_;
	return $ukupno / @_;

}

print "Prosek brojeva liste: " . avg(@listaBrojeva);
print "\nBrojevi veci od proseka su: \n";
foreach(@listaBrojeva) {
	if ($_ > avg(@listaBrojeva) ) {
	print $_ . " \n";
	}

}