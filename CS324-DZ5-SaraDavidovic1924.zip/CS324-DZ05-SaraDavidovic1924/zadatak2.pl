#! /usr/bin/perl

#2) Napisati Perl program koji čita tekstualni fajl i obrće redosled linija (prva je poslednja,
#poslednja je prva).

use strict;
use warnings;

my $ime = 'tekstualni.txt';
my @niz;
if (open(my $fh, '<:encoding(UTF-8)', $ime)) {
	while (my $row = <$fh>) {
		push (@niz, $row);
	}
	print reverse @niz;
} else {
	
	warn "Greska"
}