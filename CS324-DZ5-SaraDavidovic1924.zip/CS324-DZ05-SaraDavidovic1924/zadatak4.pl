#!/usr/bin/perl
#4) Napisati Perl sub (nazvan zip) koji prima dva niza (po referenci) iste dužina, i vraća jedan
#niz u kome je svaki i-ti element i-ti element prvog niza, a svaki i+1 element i-ti element
#drugog niza.

use strict;
use warnings;

my @a1 = (1,2,3,4);
my @a2 = ('a', 'b', 'c', 'd');


sub zip {

my($a1,$a2) = @_;

my $duzina1 = scalar @a1;
my $duzina2 = scalar @a2;

my $i;
my $j;

if($duzina1 == $duzina2) {
	foreach $i(@$a1){
		print $i . ", ";
		foreach $j(@$a2){
			print $j . ", ";
			$j++;
			last;
		
		}
	}
} else {
	warn "Greska, unesite iste duzine nizova!";
}

}
zip(\@a1, \@a2);