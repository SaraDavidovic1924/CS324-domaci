#!/usr/bin/perl
#1) Napisati Perl program koji traži od korisnika ime i vraća prezime. Koristiti imena poznatih
#ljudi ili ljudi koje poznajete.

use strict;
use warnings;
use v5.010;

print "Unesite ime Vaseg kolege: ";
my $ime = <>;
chomp $ime;

my %prezime = (
	"Sara" => "Davidovic",
	"Lazar" => "Mrkela",
	"Nemanja" => "Andric",
	"Miroslava" => "Raspopovic",
	"Milanka" => "Bjelic",
);

print $prezime{$ime};